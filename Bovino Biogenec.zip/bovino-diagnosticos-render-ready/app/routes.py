from flask import Blueprint, render_template, request, redirect, url_for
from . import db
from .models import Diagnostico

main = Blueprint('main', __name__)

@main.route('/')
def index():
    registros = Diagnostico.query.all()
    return render_template('index.html', registros=registros)

@main.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nuevo = Diagnostico(
            animal_id=request.form['animal_id'],
            fecha=request.form['fecha'],
            diagnostico=request.form['diagnostico'],
            notas=request.form['notas']
        )
        db.session.add(nuevo)
        db.session.commit()
        return redirect(url_for('main.index'))
    return render_template('registro.html')
