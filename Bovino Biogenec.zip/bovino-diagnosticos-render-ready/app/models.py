from . import db

class Diagnostico(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    animal_id = db.Column(db.String(20), nullable=False)
    fecha = db.Column(db.String(20), nullable=False)
    diagnostico = db.Column(db.String(100), nullable=False)
    notas = db.Column(db.String(200))
